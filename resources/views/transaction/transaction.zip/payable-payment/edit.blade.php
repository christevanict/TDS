@extends('layouts.master')

@section('title', 'Edit Pelunasan Hutang')

@section('css')
<style>
.nested-table {
    width: calc(100% - 40px); /* Adjust width to fit nicely under the parent row */
    margin: 0; /* Remove margin */
    border: 1px solid #ddd; /* Optional: add border for clarity */
}

.child-row {
    background-color: #f9f9f9; /* Optional: slight background for child rows */
}

.table th, .table td {
    padding: 8px; /* Adjust padding to your needs */
}

table {
    border-collapse: collapse; /* Ensures tables are neatly aligned */
}

.tooltip {
    position: relative;
    display: inline-block;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 5px;
    padding: 5px 0;

    /* Position the tooltip */
    position: absolute;
    z-index: 1;
    bottom: 125%; /* Position above the button */
    left: 50%;
    margin-left: -60px; /* Center the tooltip */
    opacity: 0;
    transition: opacity 0.3s;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
    opacity: 1;
}
</style>
@endsection

@section('content')
<div class="row">
    <x-page-title title="{{__('Payable Payment')}}" pagetitle="Edit {{__('Payable Payment')}}" />
    <hr>
    <div class="container content">
        <h2>Edit {{__('Payable Payment')}}</h2>
        <form id="print-form" target="_blank" action="{{ route('transaction.payable_payment.print', $payable->id) }}" method="GET" style="display:inline;">
            <button type="submit" class="btn btn-dark mb-3" @if(!in_array('print', $privileges)) disabled @endif>
                Print {{__('Payable Payment')}}</button>
        </form>

        <form id="payable-payment-form" action="{{ route('transaction.payable_payment.update',$payable->id) }}" method="POST">
            @csrf
            <div class="card mb-3">
                <div class="card-header">{{__('Payable Payment')}} Information</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">

                                <div class="form-group">
                                    <label for="search">{{__('Search Supplier')}}</label>
                                    <input type="text" id="search" class="form-control" placeholder="Search by Supplier Code, Name, or Address" disabled>
                                    <div id="search-results" class="list-group" style="display:none; position:relative; z-index:1000; width:100%;" >
                                        <!-- Search results will be injected here -->
                                    </div>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="supplier_code">{{__('Supplier Code')}}</label>
                                    <input type="text" name="supplier_code" id="supplier_code" class="form-control" value="{{$payable->supplier->supplier_code}}"  disabled>
                                    <input type="hidden" name="category_customer" id="category_customer" class="form-control"  disabled>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="supplier_name">{{__('Supplier Name')}}</label>
                                    <input type="text" name="supplier_name" id="supplier_name" class="form-control" value="{{$payable->supplier->supplier_name}}" disabled>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="address">{{__('Address')}}</label>
                                    <input type="text" name="address" id="address" class="form-control" value="{{$payable->supplier->address}}" disabled>
                                </div>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-4">
                                <label for="document_date">Nomor {{__('Payable Payment')}}</label>
                                <input type="text" name="document_date" class="form-control"  value="{{$payable->payable_payment_number}}" disabled>
                            </div>

                            <div class="form-group">
                                <input type="hidden" name="department_code" id="department_code" class="form-control" readonly value="{{ $departments->department_code }}" required>
                                <label for="document_date">Tanggal {{__('Payable Payment')}}</label>
                                <input type="date" name="document_date" class="form-control date-picker" required value="{{ date('Y-m-d') }}" disabled>
                            </div>
                            <br>
                            <div class="form-group">
                                <label for="acc_disc">Akun Diskon</label>
                                <div class="form-group mb-3">
                                    <div class="input-group">
                                        <input type="text" id="search-acc-disc" class="form-control" placeholder="Search by Account Number or Account Name" required readonly value="{{$payable->acc_disc.' - '.$coas->firstWhere('account_number',$payable->acc_disc)->account_name}}" >
                                        <button style="height:100%;" class="btn btn-outline-secondary" type="button" onclick="clearInput('search-acc-disc')"><i class="material-icons-outlined">edit</i></button>
                                    </div>
                                    <div id="search-result-acc-disc" class="list-group" style="display:none; position:relative; z-index:1000; width:100%; max-height:200px; overflow:scroll;">
                                        <!-- Search results will be injected here -->
                                    </div>
                                    <input type="hidden" name="acc_disc" id="acc_disc" value="{{$payable->acc_disc}}">
                                </div>
                                <div class="form-group mb-3" id="pay-row">
                                    <button type="button" class="btn btn-info" id="btnPayment">
                                        Detail Metode Pembayaran
                                    </button>
                                    <br>
                                    <h5 >Total Pembayaran: <span id="total-payment-value">{{number_format($payable->total_debt,0,'.',',')}}</span></h5>
                                    <input type="hidden" id="payment_details"  />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dynamic Table for Payable Payment Details -->
            <div class="card mb-3">
                <div class="card-header">Detail {{__('Payable Payment')}}</div>
                <div class="card-body">
                    <h5 class="text-end">Total Pembayaran: <span id="total-value">{{number_format($payable->total_debt,0,'.',',')}}</span></h5>
                    <table class="table" id="dynamicTable">
                        <thead>
                            <tr>
                                <td>Nomor Dokumen</td>
                                <td>Tanggal Dokumen</td>
                                <td>Sisa Hutang</td>
                                <td>Nominal Pembayaran</td>
                                <td>Diskon</td>
                                <td>Total</td>
                            </tr>
                        </thead>
                        <tbody id="parentTbody">
                            @foreach ($payable_details as $index => $detail)
                                <tr>
                                    <td style="min-width:250px;">
                                        <input type="text" name="details[{{ $index }}][document_number]" class="form-control" placeholder="Document Number" value="{{ $detail->document_number }}" readonly />
                                    </td>
                                    <td>
                                        <input type="text" name="details[{{ $index }}][document_date]" class="form-control" placeholder="Document Date" value="{{ substr($detail->document_date,0,10) }}" readonly />
                                    </td>
                                    <td>
                                        <input type="text" name="details[{{ $index }}][debt_balance]" class="form-control text-end" placeholder="Debt Balance" value="{{ number_format($detail->document_payment,0,'.',',') }}" readonly />
                                    </td>
                                    <td>
                                        <input type="text" name="details[{{ $index }}][nominal_payment]" class="form-control text-end" placeholder="Nominal Payment" value="{{ number_format($detail->nominal_payment,0,'.',',') }}" />
                                    </td>
                                    <td>
                                        <input type="text" name="details[{{ $index }}][discount]" class="form-control text-end" placeholder="Discount" value="{{ number_format($detail->discount,0,'.',',') }}" />
                                    </td>
                                    <td>
                                        <input type="text" name="details[{{ $index }}][discount]" class="form-control text-end nominal" placeholder="Discount" value="{{ number_format(($detail->nominal_payment - $detail->discount),0,'.',',') }}" />
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Modal for Payment Details -->
<div class="modal fade" id="detailsModal" tabindex="-1" aria-labelledby="detailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailsModalLabel">Payment Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table details-table">
                    <thead>
                        <tr>
                            <th>Metode Pembayaran</th>
                            <th>Nominal</th>
                            <th>Nomor BG Check</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="details-body">
                        <!-- Dynamic details rows will be added here -->
                    </tbody>
                </table>
                <button type="button" class="btn btn-primary" id="addDetailRow">Tambah Detail Pembayaran</button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" id="saveDetails">Simpan Detail Pembayaran</button>
            </div>
        </div>
    </div>
</div>

            <div class="form-group submit-btn mb-3">
                {{-- <button type="submit" class="btn btn-success">Update Payable Payment</button> --}}
            </div>
            <a class=" mb-3 btn btn-secondary" href="{{route('transaction.payable_payment')}}">Back</a>
        </form>
        {{-- <form id="delete-form" action="{{ route('transaction.payable_payment.destroy', $payable->id) }}" method="POST" style="display:inline;" >
            @csrf
            @method('POST')
            <button type="button" class="btn btn-sm btn-danger mb-3" onclick="confirmDelete(event,'{{ $payable->id }}')"
                @if(Auth::user()->role != 5 && Auth::user()->role != 7)
                    style="display: none"
                @endif
            ><i class="material-icons-outlined">delete</i></button>
        </form> --}}
    </div>

    @if (session('success'))
        <script>
            Swal.fire({
                title: 'Success!',
                text: "{{ session('success') }}",
                icon: 'success',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "{{ route('transaction.sales_order') }}"; // Redirect to list page
                }
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            Swal.fire({
                title: 'Error!',
                text: "{{ session('error') }}",
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>
    @endif
</div>

@section('scripts')
<script>
    let supplierId='';
    const coas = @json($coas);
    const details = @json($payable_detail_pays);
    function setupSearch(inputId, resultsContainerId,inputHid) {
        const inputElement = document.getElementById(inputId);
        const resultsContainer = document.getElementById(resultsContainerId);
        inputElement.addEventListener('input', function () {
            let query = this.value.toLowerCase();
            resultsContainer.innerHTML = '';
            resultsContainer.style.display = 'none';
            if (query.length > 0) {
                let filteredResults = coas.filter(item =>
                    item.account_number.toLowerCase().includes(query) ||
                    item.account_name.toLowerCase().includes(query)
                );
                if (filteredResults.length > 0) {
                    resultsContainer.style.display = 'block';
                    filteredResults.forEach(item => {
                        let listItem = document.createElement('a');
                        listItem.className = 'list-group-item list-group-item-action';
                        listItem.href = '#';
                        listItem.innerHTML = `
                            <strong>${item.account_number}</strong> -
                            ${item.account_name} <br>`;
                        listItem.addEventListener('click', function(e) {
                            e.preventDefault();
                            inputElement.value = item.account_number + ' - ' + item.account_name;
                            inputElement.readOnly = true;
                            document.getElementById(inputHid).value = item.account_number;
                            resultsContainer.style.display = 'none';
                        });
                        resultsContainer.appendChild(listItem);
                    });
                }
            }
        });
    }
    function clearInput(inputId) {
        document.getElementById(inputId).value = '';
        document.getElementById(inputId).readOnly = false;
    }
    setupSearch('search-acc-disc', 'search-result-acc-disc','acc_disc');

    function confirmDelete(event, id) {
        event.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: 'Do you want to delete this {{__('Payable Payment')}}?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            confirmButtonColor: '#0c6efd',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form').submit();
            }
        });
    }
    const suppliers = @json($suppliers);

    document.getElementById('search').addEventListener('input', function () {
        let query = this.value.toLowerCase();
        let resultsContainer = document.getElementById('search-results');
        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'none';
        if (query.length > 0) {
            let filteredsuppliers = suppliers.filter(c =>
                c.supplier_code.toLowerCase().includes(query) ||
                c.supplier_name.toLowerCase().includes(query) ||
                c.address.toLowerCase().includes(query));
            if (filteredsuppliers.length > 0) {
                resultsContainer.style.display = 'block';
                filteredsuppliers.forEach(customer => {
                    let listItem = document.createElement('a');
                    listItem.className = 'list-group-item list-group-item-action';
                    listItem.href = '#';
                    listItem.innerHTML = `
                        <strong>${customer.supplier_code}</strong> -
                        ${customer.supplier_name} <br>
                        <small>${customer.address}</small>`;
                    listItem.addEventListener('click', function(e) {
                        e.preventDefault();
                        document.getElementById('supplier_code').value = customer.supplier_code;
                        document.getElementById('supplier_name').value = customer.supplier_name;
                        document.getElementById('address').value = customer.address;
                        resultsContainer.style.display = 'none';

                        supplierId = supplier.supplier_code;
                    if (supplierId === "") {
                        $('#invoiceTable tbody tr').show();
                    } else {
                        // Hide rows that do not match the selected customer
                        $('#invoiceTable tbody tr').each(function () {
                            const selectedSuppliers = $(this).data('supplier-id');
                            if (selectedSuppliers == supplierId) {
                                $(this).show();
                            } else {
                                $(this).hide();
                            }
                        });
                    }

                    });
                    resultsContainer.appendChild(listItem);});
                }
            }
    });
    document.addEventListener('click', function(event) {
        if (!event.target.closest('#search')) {
            document.getElementById('search-results').style.display = 'none';
            document.getElementById('search').value=''; }});
    function formatNumber(number) {
        return new Intl.NumberFormat('id-ID').format(number);
    }
    function updateCustomerInfo() {
        const supplierselect = document.getElementById('supplier_code');
        const selectedOption = supplierselect.options[supplierselect.selectedIndex];

        // Get Supplier Name and address from the selected option
        const customerName = selectedOption.getAttribute('data-customer-name');
        const address = selectedOption.getAttribute('data-address');

        // Set the values in the readonly fields
        document.getElementById('supplier_name').value = customerName;
        document.getElementById('address').value = address;
    }
    let rowCount = 0;
    // Initialize row count // Tracks main pay details rows
    $('#addRow').click(function() {
        const newRow = `
            <tr>
                <th>Document Nominal</th>
                <th>Document Payment</th>
                <th>Nominal Payment</th>
                <th>Discount</th>
                <th>Actions</th>
            </tr>
            <tr>
                <td>
                    <input type="number" name="details[${rowCount}][document_nominal]" class="form-control" placeholder="Document Nominal" />
                </td>
                <td>
                    <input type="number" name="details[${rowCount}][document_payment]" class="form-control" placeholder="Document Payment" />
                </td>
                <td>
                    <input type="number" name="details[${rowCount}][nominal_payment]" class="form-control" placeholder="Document Payment" />
                </td>
                <td>
                    <input type="number" name="details[${rowCount}][discount]"  class="form-control" placeholder="Document Payment" />
                </td>
                <td id="pay-row-${rowCount}">
                    <button type="button" class="btn btn-danger deleteRow"><i class="material-icons-outlined remove-row">remove</i></button>
                    <button type="button" class="btn btn-secondary addDetails" title="Add Payment Details" data-parent-row="${rowCount}" data-child-row-count="0"><i class="material-icons-outlined remove-row">attach_money</i></button>
                </td>
            </tr>
        `;
        rowCount++;
        $('#parentTbody').append(newRow); // Append to the parent tbody


    });

    $(document).on('click', '.addDetails', function() {
        const parentRowIndex = $(this).data('parent-row');
        $('#detailsModal').data('parent-row', parentRowIndex).modal('show');
    });


    // Delete Row
    $(document).on('click', '.deleteRow', function() {
        const rowCount = $(this).closest('tr');
        const rowToDelete = rowCount.prev('tr');
        const detailRow = rowCount.next('.detail-row');

        // Remove detail row if it exists
        if (detailRow.length) {
            detailRow.remove();
        }

        // Remove the main row
        rowToDelete.remove();
        rowCount.remove();
    });

    // Add Details
    // Save Details Functionality
    function saveDetails() {
        const parentRowIndex = $('#detailsModal').data('parent-row');
        const detailsBody = $('#detailsModal').find('.details-body');

        // Prepare an array to hold the details
        const detailsArray = [];

        $(`#pay-row-${parentRowIndex} input[type="hidden"]`).filter(function() {
            return !$(this).attr('id'); // Exclude inputs that have an ID
        }).remove();

        // Loop through each detail row and collect the data
        detailsBody.find('tr').each(function(index) {
            const paymentMethod = $(this).find('select[name^="details[' + parentRowIndex + '][payment_details]"][name$="[payment_method]"] option:selected').val();
            const nominal = $(this).find('input[name^="details[' + parentRowIndex + '][payment_details]"][name$="[payment_nominal]"]').val();
            const bgCheckNumber = $(this).find('input[name^="details[' + parentRowIndex + '][payment_details]"][name$="[bg_check_number]"]').val();

            // Push the collected data into the array

            const detail = {
                payment_method: paymentMethod,
                payment_nominal: nominal,
                bg_check_number: bgCheckNumber,
            }
            detailsArray.push(detail);

            const hiddenInput = `
                <input type="hidden" name="details[${parentRowIndex}][payment_details][${index}][payment]" value='${JSON.stringify(detail)}' />
            `;

            // Append the hidden input to the specified <td>
            $(`#pay-row-${parentRowIndex}`).append(hiddenInput)
        });

        // Set the collected details back to the main form (hidden input)
        $('input[id="details[' + parentRowIndex + '][payment_details]"]').val(JSON.stringify(detailsArray));

        // Close the modal
        $('#detailsModal').modal('hide');
    }

    // Event listener for Save Details button
    $('#saveDetails').click(function() {
        saveDetails();
    });

    // Event listener for Close button
    $('#closeModal').click(function() {
        saveDetails(); // Save data before closing
    });

    $('#btnPayment').click(function() {
        $('#detailsModal').modal('show');
    });

    // Show the modal and populate it with existing data
    $('#detailsModal').on('show.bs.modal', function () {
        const parentRowIndex = $(this).data('parent-row');
        const detailsBody = $(this).find('.details-body');
        detailsBody.empty(); // Clear existing rows


        function groupAndSum(data) {
            const grouped = data.reduce((acc, { payment_method, payment_nominal, bg_check_number }) => {
                const key = `${payment_method}-${bg_check_number || 'NO_BG'}`;
                if (!acc[key]) {
                    acc[key] = { payment_method, bg_check_number, total_nominal: 0 };
                }
                acc[key].total_nominal += parseFloat(payment_nominal);
                return acc;
            }, {});

            // Convert the grouped object to an array of values so you can use forEach
            return Object.values(grouped);
        }

        const groupedData = groupAndSum(details);

        // Populate the modal with existing details
        groupedData.forEach((detail, index) => {
            const detailRow = `
                <tr>
                    <td>
                        <select class="form-control" name="details[${parentRowIndex}][payment_details][${index}][payment_method]">
                            @foreach ($paymentMethods as $method)
                                <option value="{{ $method->payment_method_code }}" ${detail.payment_method === '{{ $method->payment_method_code }}' ? 'selected' : ''}>
                                    {{ $method->payment_name }} ({{ $method->payment_method_code }})
                                </option>
                            @endforeach
                        </select>
                    </td>
                    <td><input type="text" placeholder="Nominal" class="form-control" name="details[${parentRowIndex}][payment_details][${index}][payment_nominal]" value="${detail.total_nominal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}" /></td>
                    <td><input type="number" placeholder="BG Check Number" class="form-control" name="details[${parentRowIndex}][payment_details][${index}][bg_check_number]" value="${detail.bg_check_number}" /></td>
                    <td><button class="btn btn-danger deleteDetail"><i class="material-icons-outlined remove-row">remove</i></button></td>
                </tr>
            `;
            detailsBody.append(detailRow);
        });
    });

    $('#addDetailRow').click(function() {
        const parentRowIndex = $('#detailsModal').data('parent-row');
        const detailsBody = $('#detailsModal').find('.details-body');
        let childRowCount = $(this).data('child-row-count') || 0;
        const newRow = `
            <tr>
                <td>
                    <select class="form-control" name="details[${parentRowIndex}][payment_details][${childRowCount}][payment_method]">
                            @foreach ($paymentMethods as $meth)
                                <option value="{{$meth->payment_method_code}}">{{$meth->payment_name.' ('.$meth->payment_method_code.')'}}</option>
                            @endforeach
                        </select>
                </td>
                <td><input type="number" placeholder="Nominal" class="form-control" name="details[${parentRowIndex}][payment_details][${childRowCount}][payment_nominal]" /></td>
                <td><input type="number" placeholder="BG Check Number" class="form-control" name="details[${parentRowIndex}][payment_details][][bg_check_number]" /></td>
                <td><button class="btn btn-danger deleteDetail"><i class="material-icons-outlined remove-row">remove</i></button></td>
            </tr>
        `;
        detailsBody.append(newRow);
    });


    // Delete Payment Detail Row
    $(document).on('click', '.deleteDetail', function() {

        $(this).closest('tr').remove();// Remove the detail row
    });

</script>
@endsection

@endsection
