@extends('layouts.master')

@section('title', 'Input Sales Order')
@section('css')
<style>
    #search-result-dest {
        max-height: 200px; /* Set your desired maximum height */
        overflow-y: auto; /* Enable vertical scrolling */
        border: 1px solid #ccc; /* Optional: Add a border */
        background-color: #fff; /* Optional: Set a background color */
        display: none; /* Initially hidden */
    }
</style>
@endsection
@section('content')
<div class="row">
    <x-page-title title="{{__('Sales Order')}}" pagetitle="{{__('Sales Order')}} Input" />
    <hr>
    <div class="container content">
        <h2>{{__('Sales Order')}} Input</h2>

        <div id="message-container">
            @if(session('success'))
                <div id="success-message" class="alert alert-success fade show">{{ session('success') }}</div>
            @endif
            @if($errors->any())
                <div id="error-message" class="alert alert-danger fade show">
                    <ul>
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>

        <form id="bank-cash-out-form" action="{{ isset($salesOrder) ? route('transaction.sales_order.update', $salesOrder->id) : route('transaction.sales_order.store') }}" method="POST">
            @csrf
            @if(isset($salesOrder)) @method('PUT') @endif
            <input type='hidden' id="checkHPP" name='checkHPP' value=0 />
            <div class="card mb-3">
                <div class="card-header">{{__('Sales Order')}} {{__('Information')}}</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">

                                <div class="form-group">
                                    <label for="search">{{__('Search Customer')}}</label>
                                    <input type="text" id="search" class="form-control" placeholder="Search by Customer Code, Name, or Address">
                                    <div id="search-results" class="list-group" style="display:none; position:relative; z-index:1000; width:100%;">
                                        <!-- Search results will be injected here -->
                                    </div>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="customer_code">{{__('Customer Code')}}</label>
                                    <input type="text" name="customer_code" id="customer_code" class="form-control" readonly required>
                                    <input type="hidden" name="category_customer" id="category_customer" class="form-control" readonly>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="customer_name">{{__('Customer Name')}}</label>
                                    <input type="text" name="customer_name" id="customer_name" class="form-control" readonly required>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label for="address">{{__('Address')}}</label>
                                    <input type="text" name="address" id="address" class="form-control" readonly>
                                </div>
                            {{-- <div class="form-group">
                                <label for="sales_order_number">{{__('Sales Order Number')}}</label>
                                <input type="text" name="sales_order_number" class="form-control" readonly required value="{{ old('sales_order_number', $salesOrder->sales_order_number ?? $sales_order_number) }}">
                            </div> --}}
                            <br>

                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="notes">Note</label>
                                <textarea name="notes" class="form-control" rows="5">{{ old('notes', $salesOrder->notes ?? '') }}</textarea>
                            </div>
                            <br>
                            <div class="form-group">
                                <label for="document_date">{{__('Document Date')}}</label>
                                <input type="date"  name="document_date" class="form-control date-picker" required value="{{ old('document_date', $salesOrder->document_date ?? date('Y-m-d')) }}" id="document_date">
                            </div>
                            <br>
                            <div class="form-group">
                                <label for="delivery_date">{{__('Delivery Date')}}</label>
                                <input type="date" name="delivery_date" class="form-control date-picker" required value="{{ old('delivery_date', $salesOrder->delivery_date ?? date('Y-m-d')) }}">
                            </div>
                            <br>
                            <div class="form-group">
                                <label for="due_date">{{__('Due Date')}}</label>
                                <input type="date" name="due_date" class="form-control date-picker" required value="{{ old('due_date', $salesOrder->due_date ?? date('Y-m-d')) }}">
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="department_code">{{__('Department Code')}}</label>
                                <input type="hidden" name="department_code" class="form-control" value="{{$department_MBE}}">
                                <input type="text" name="department_name" id="department_name" class="form-control" value="{{$department_MBEn->department_name}}" readonly>
                                {{-- <div class="input-group mb-3">
                                    <select class="form-select" id="department_code" name="department_code" required readonly>
                                        @foreach ($departments as $department)
                                            <option value="{{$department_MBE}}" {{ $department->department_code == $department_MBE ? 'selected' : '' }}>{{$department->department_name}}</option>
                                        @endforeach
                                    </select>
                                </div> --}}
                            </div>
                            <br>
                            <div class="form-group d-none">
                                <label for="disc_nominal">{{__('Discount')}}</label>
                                <input type="text" oninput="formatNumber(this)" name="disc_nominal" id="disc_nominal" class="form-control text-end nominal" required value="0">
                            </div>
                            <br>
                            {{-- <div class="form-group">
                                <label for="tax">Tax</label>
                                <div class="input-group mb-3">
                                    <select class="form-select" id="tax" name="tax" required>
                                        @foreach ($taxs as $tax)
                                            <option value="{{$tax->tax_code}}">{{$tax->tax_name.' ('.$tax->tax_code.')'}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div> --}}
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    <select hidden class="form-select" id="company_code" name="company_code" required>
                                        @foreach ($companies as $company)
                                            <option value="{{$company->company_code}}">{{$company->company_name.' ('.$company->company_code.')'}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <br>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card for Sales Order Details -->
            <div class="card mb-3">
                <div class="card-header">{{__('Sales Order')}} Details</div>
                <div class="card-body">
                    <h5 class="text-end">Total sebelum pajak: <span id="total-value">0</span></h5>
                    <div style="overflow-x: auto;">
                    <table class="table" id="cash-out-details-table">
                        <thead>
                            <tr>
                                <th style="min-width: 430px">{{__('Item')}}</th>
                                <th style="min-width: 150px">Qty</th>
                                <th style="min-width: 150px">Unit</th>
                                <th style="min-width: 200px">{{__('Price')}} / Unit Dasar</th>
                                <th style="min-width: 150px">{{__('Discount')}} (%)</th>
                                <th style="min-width: 200px">{{__('Discount')}}</th>
                                <th style="min-width: 200px">Nominal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($salesOrder) && $salesOrder->details)
                                {{-- @foreach($salesOrder->details as $detail)
                                    <tr>
                                        <td>
                                            <div class="input-group mb-3">
                                                <select class="form-select" id="account_number" name="details[{{ $loop->index }}][account_number]" required value="{{ old('details.' . $loop->index . '.account_number_header', $detail->account_number_header) }}">
                                                    @foreach ($coas as $coa)
                                                        <option data-company="{{$coa->company_code}}" value="{{$coa->account_number}}">{{$coa->account_number.' - '.$coa->account_name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </td>
                                        <td>
                                            <input type="number" step="0.01" name="details[{{ $loop->index }}][nominal_debet]" class="form-control" required value="{{ old('details.' . $loop->index . '.nominal', $detail->nominal) }}">
                                        </td>
                                        <td>
                                            <input type="number" step="0.01" name="details[{{ $loop->index }}][nominal_credit]" class="form-control" required value="{{ old('details.' . $loop->index . '.nominal', $detail->nominal) }}">
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger remove-row"><i class="material-icons-outlined remove-row">delete</i></button>
                                        </td>
                                    </tr>
                                @endforeach --}}
                            @else
                                <tr data-row-id="0">
                                    <td>
                                        <div class="form-group">
                                            <input type="hidden" class="form-control item-input" name="details[0][item_id]" id="item_code_0" placeholder="{{__('Search Item')}}">
                                            <input type="text" class="form-control item-input" name="details[0][item_name]" id="item-search-0" placeholder="{{__('Search Item')}}">
                                            <div id="item-search-results-0" class="list-group" style="display:none; position:relative; z-index:1000; width:100%;">
                                                <!-- Search results will be injected here -->
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <input type="text"  name="details[0][qty]" id="qty_0" class="form-control" value="1" min="1" required placeholder="Quantity">
                                    </td>
                                    <td>
                                        <select id="unit_0" name="details[0][unit]" class="form-control unit-dropdown">
                                            @foreach ($itemUnits as $unit)
                                                <option value="{{$unit->unit}}">{{$unit->unit_name}}</option>
                                            @endforeach
                                        </select>
                                        <input type="hidden" id="conversion_value_0" name="details[0][conversion_value]" />
                                    </td>
                                    {{-- <td>
                                        <div class="input-group mb-3">
                                            <select class="form-select" id="unit_0" name="details[0][unit]" required>
                                                <option></option>
                                                @foreach ($itemUnits as $unit)
                                                    <option data-company="{{$unit->company_code}}" value="{{$unit->unit}}">{{$unit->unit_name.' ('.$unit->unit.')'}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </td> --}}
                                    <td>
                                        <input type="text" name="details[0][price]"
                                        oninput="formatNumber(this)" id="price_0" class="form-control text-end" value="0"  required placeholder="{{__('Price')}}">
                                    </td>
                                    <td>
                                        <input type="text" name="details[0][disc_percent]" max="100" id="disc_percent_0" oninput="formatNumber(this)" class="form-control text-end" value="0" required placeholder="% Discount">
                                    </td>
                                    <td>
                                        <input type="text" name="details[0][disc_nominal]" oninput="formatNumber(this)" id="disc_nominal_0" class="form-control text-end" value="0" required placeholder="Discount">
                                    </td>
                                    <td>
                                        <input type="text" name="details[0][nominal]" oninput="formatNumber(this)" readonly id="nominal_0" class="form-control text-end nominal" value="0" required placeholder="Discount">
                                    </td>
                                    {{-- <td>
                                        <select class="form-select" id="status" name="details[0][status]">
                                            <option value="Not">Not Ready</option>
                                            <option value="Ready">Ready</option>
                                        </select>
                                    </td> --}}
                                    <td>
                                        <button type="button" class="btn btn-danger remove-row"><i class="material-icons-outlined remove-row">delete</i></button>
                                    </td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                    </div>
                    <button type="button" id="add-row" class="btn btn-primary mt-3">Add Detail</button>
                </div>
            </div>

            <div class="form-group submit-btn mb-3">
                <button type="submit" class="btn btn-success" @if(!in_array('create', $privileges)) disabled @endif>Submit {{__('Sales Order')}}</button>
            </div>
        </form>
    </div>

    @if (session('success'))
        <script>
            Swal.fire({
                title: 'Success!',
                text: "{{ session('success') }}",
                icon: 'success',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "{{ route('transaction.sales_order') }}"; // Redirect to list page
                }
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            Swal.fire({
                title: 'Error!',
                text: "{{ session('error') }}",
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>
    @endif
</div>

@section('scripts')
<script>



document.addEventListener('DOMContentLoaded', function () {
            // Check if the success message is present
            @if(session('success'))
                // Show SweetAlert confirmation modal
                Swal.fire({
                    title: '{{__('Sales Order')}} Created',
                    text: 'Do you want to print it?',
                    icon: 'success',
                    showCancelButton: true,
                    confirmButtonText: 'Yes',
                    cancelButtonText: 'No',
                }).then((result) => {
                    if (result.isConfirmed) {
                        // User clicked "Yes"
                        var id = "{{ session('id') }}"; // Get the id from the session
                        if (id) {
                            // Navigate to the edit route with the id
                            window.location.href = "{{ route('transaction.sales_order.print', ['id' => ':id']) }}".replace(':id', id);
                        }
                    }
                });
            @endif
        });

var now = new Date(),
maxDate = now.toISOString().substring(0,10);
$('#document_date').prop('max', maxDate);
var itemDetails = @json($itemDetails);
let items = @json($items);
    function setupItemSearch(rowId) {
        // Add event listener for the new row's search input
        document.getElementById(`item-search-${rowId}`).addEventListener('input', function() {
            let query = this.value.toLowerCase();
            let resultsContainer = document.getElementById(`item-search-results-${rowId}`);
            resultsContainer.innerHTML = ''; // Clear previous results
            resultsContainer.style.display = 'none'; // Hide dropdown by default

            if (query.length > 0) {
                // Assuming `items` is an array of item data
                let filteredItems = items.filter(item =>
                    item.item_code.toLowerCase().includes(query) ||
                    item.items.item_name.toLowerCase().includes(query)
                );

                if (filteredItems.length > 0) {
                    resultsContainer.style.display = 'block'; // Show dropdown if matches found

                    // Populate dropdown with filtered results

                    filteredItems.forEach(item => {
                        let listItem = document.createElement('a');
                        listItem.className = 'list-group-item list-group-item-action';
                        listItem.href = '#';
                        listItem.innerHTML = `
                            <small><strong>${item.items.item_name}</strong> (${item.item_code})</small>
                        `;

                        // On selecting an item from the dropdown
                        listItem.addEventListener('click', function(e) {
                            let units = [];

                            item.item_details.forEach(element => {
                                units.push(element.unit_conversion);
                            });

                            e.preventDefault();
                            document.querySelector(`input[name="details[${rowId}][item_id]"]`).value = item.item_code;
                            document.querySelector(`input[name="details[${rowId}][item_name]"]`).value = item.items.item_name;
                            const unitSelect = document.getElementById(`unit_${rowId}`);
                            Array.from(unitSelect.options).forEach(option => {
                                if (!units.includes(option.value)) {
                                    option.style.display = "none";
                                }
                            });

                            unitSelect.value = item.unit;
                            document.getElementById(`price_${rowId}`).value = item.sales_price.split('.')[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                            let selectedUnit = document.getElementById(`unit_${rowId}`).value;
                            var conversionValue = itemDetails.find((i)=>i.item_code == item.item_code&&i.unit_conversion ==selectedUnit).conversion;
                            document.getElementById(`conversion_value_${rowId}`).value = conversionValue;
                            document.getElementById(`nominal_${rowId}`).value = (item.sales_price*conversionValue).toString().split('.')[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                            resultsContainer.style.display = 'none'; // Hide dropdown after selection
                            calculateTotals();
                            addInputListeners();

                        });

                        resultsContainer.appendChild(listItem); // Add item to dropdown
                    });
                }
            }
        });
    }

    function setupUnitChangeListener(rowNumber) {
        // Construct the IDs based on the row number
        var selectId = 'unit_' + rowNumber;
        var hiddenInputId = 'conversion_value_' + rowNumber;



        document.getElementById(selectId).addEventListener('change', function() {
            var itemCode = document.getElementById(`item_code_${rowNumber}`).value;
            var selectedOption = this.options[this.selectedIndex];
            var conversionValue = itemDetails.find((i)=>i.item_code == itemCode&&i.unit_conversion ==selectedOption.value).conversion;
            document.getElementById(hiddenInputId).value = conversionValue;
        });
    }
    setupItemSearch(0);
    setupUnitChangeListener(0);

    function updateNominalValue(row) {
        const qty = parseFloat(document.getElementById(`qty_${row}`).value) || 0;
        const price = document.getElementById(`price_${row}`).value.replace(/,/g, '') || 0;
        const disc_nominal_header = document.getElementById('disc_nominal').value.replace(/,/g, '') || 0;
        const disc_percent = document.getElementById(`disc_percent_${row}`).value.replace(/,/g, '') || 0;
        const disc_nominal = document.getElementById(`disc_nominal_${row}`).value.replace(/,/g, '') || 0;
        const conversion = document.getElementById(`conversion_value_${row}`).value.replace(/,/g, '') || 0;
        // const disc_percent = parseFloat(document.getElementById(`disc_percent_${row}`).value.replace(/,/g, '')) || 0;
        // const disc_nominal = parseFloat(document.getElementById(`disc_nominal_${row}`).value.replace(/,/g, '')) || 0;

        const nominalInput = document.getElementById(`nominal_${row}`);
        const nominalValue = ((qty * price)-((qty * price)*disc_percent/100)-disc_nominal)*parseFloat(conversion)+"";


        let formattedValue = nominalValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

        nominalInput.value = formattedValue; // Update nominal value
        calculateTotals();
    }

    function formatNumber(input) {
        // Get the cursor position
        const cursorPosition = input.selectionStart;
        input.value = input.value.replace(/[^0-9]/g, '');
        // Remove any existing thousand separators
        let value = input.value.replace(/,/g, '');

        // Format the number with thousand separators
        let formattedValue = value.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

        // Set the new value
        input.value = formattedValue;

        // Adjust the cursor position
        const newCursorPosition = formattedValue.length - (value.length - cursorPosition);
        input.setSelectionRange(newCursorPosition, newCursorPosition);
    }
    function updatePrice() {
        const rowId = this.closest('tr').getAttribute('data-row-id');
        const itemCode = document.getElementById(`item_code_${rowId}`).value;

        const itemDetail = itemDetails.find(detail => detail.item_code === itemCode);
            // console.log(itemDetail);
    }

    document.getElementById(`item_code_0`).addEventListener('change', updatePrice);
    document.getElementById(`qty_0`).addEventListener('input', function() {
        updateNominalValue(0); // Call the function when the event occurs
    });

    document.getElementById(`price_0`).addEventListener('input', function() {
        updateNominalValue(0); // Call the function when the event occurs
    });
    document.getElementById(`disc_percent_0`).addEventListener('input', function() {
        updateNominalValue(0); // Call the function when the event occurs
    });

    document.getElementById(`disc_nominal_0`).addEventListener('input', function() {
        updateNominalValue(0); // Call the function when the event occurs
    });

    function calculateTotals() {
        let total = 0;
        const disc_nominal = document.getElementById('disc_nominal').value.replace(/,/g, '') || 0;
        document.querySelectorAll('.nominal').forEach(function (input) {

            input.value = input.value.replace(/,/g, ''); // Remove any thousand separators
            if(input.id=='disc_nominal'){
                total -= parseFloat(input.value) || 0;
            }else{
                total += parseFloat(input.value) || 0;
            }
            const cursorPosition = input.selectionStart;
            let value = input.value.replace(/,/g, '');
            // Format the number with thousand separators
            let formattedValue = value.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

            // Set the new value
            input.value = formattedValue;

            // Adjust the cursor position
            const newCursorPosition = formattedValue.length - (value.length - cursorPosition);
            input.setSelectionRange(newCursorPosition, newCursorPosition);
        });
        let strTotal = (total)+"";
        let value2 = strTotal.replace(/,/g, '');
            // Format the number with thousand separators
        let formattedValue2 = value2.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        document.getElementById('total-value').innerText = formattedValue2;

        return { total }; // Return totals for validation
    }
    calculateTotals();
    document.getElementById('disc_nominal').addEventListener('input',function(){
        calculateTotals();
    });
    function addInputListeners() {
        document.querySelectorAll('.nominal').forEach(function (input) {
            input.addEventListener('change', function () {

                calculateTotals(); // Calculate totals when any input changes
            });
        });
    }
    addInputListeners();

    // document.getElementById('tax').value = '';
    const customers = @json($customers);


    var rowCount=1;
    document.getElementById('search').addEventListener('input', function () {
        let query = this.value.toLowerCase();
        let resultsContainer = document.getElementById('search-results');
        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'none';
        if (query.length > 0) {
            let filteredCustomers = customers.filter(c =>
                c.customer_code.toLowerCase().includes(query) ||
                c.customer_name.toLowerCase().includes(query) ||
                c.address.toLowerCase().includes(query));
            if (filteredCustomers.length > 0) {
                resultsContainer.style.display = 'block';
                filteredCustomers.forEach(customer => {
                    let listItem = document.createElement('a');
                    listItem.className = 'list-group-item list-group-item-action';
                    listItem.href = '#';
                    listItem.innerHTML = `
                        <strong>${customer.customer_code}</strong> -
                        ${customer.customer_name} <br>
                        <small>${customer.address}</small>`;
                    listItem.addEventListener('click', function(e) {
                        e.preventDefault();
                        document.getElementById('customer_code').value = customer.customer_code;
                        document.getElementById('customer_name').value = customer.customer_name;
                        document.getElementById('address').value = customer.address;
                        document.getElementById('category_customer').value = customer.category_customer;
                        resultsContainer.style.display = 'none';

                        // for (let i = 0; i < rowCount; i++) {
                        //     document.getElementById(`item_code_${rowCount-1}`).value="";
                        //     // document.getElementById(`unit_${rowCount-1}`).value="";
                        //     document.getElementById(`price_${rowCount-1}`).value="";
                        // }

                    });
                    resultsContainer.appendChild(listItem);});}}});

    document.addEventListener('click', function(event) {
        if (!event.target.closest('#search')) {
            document.getElementById('search-results').style.display = 'none';
            document.getElementById('search').value=''; }});

        function updateCustomerInfo() {
            const customerSelect = document.getElementById('customer_code');
            const selectedOption = customerSelect.options[customerSelect.selectedIndex];

            // Get customer name and address from the selected option
            const customerName = selectedOption.getAttribute('data-customer-name');
            const address = selectedOption.getAttribute('data-address');

            // Set the values in the readonly fields
            document.getElementById('customer_name').value = customerName;
            document.getElementById('address').value = address;
        }
    // Initialize row count

    document.addEventListener('DOMContentLoaded', function () {

        // Function to add a new row
        function addNewRow() {
            const detailsTableBody = document.querySelector('#cash-out-details-table tbody');
            const newRow = document.createElement('tr');
            newRow.setAttribute('data-row-id', rowCount); // Set unique row identifier
            const currentRow = rowCount;
            newRow.innerHTML = `
                <td>
                    <div class="input-group">
                        <input type="hidden" id="item_code_${rowCount}" class="form-control item-input" name="details[${rowCount}][item_id]" placeholder="{{__('Search Item')}}">
                        <input type="text" class="form-control item-input" name="details[${rowCount}][item_name]" id="item-search-${rowCount}" placeholder="{{__('Search Item')}}">
                        <div id="item-search-results-${rowCount}" class="list-group" style="display:none; position:relative; z-index:1000; width:100%;">
                            <!-- Search results will be injected here -->
                        </div>
                    </div>
                </td>
                <td>
                    <input type="number" id="qty_${rowCount}" name="details[${rowCount}][qty]" class="form-control" value="1" min="1"  required placeholder="Quantity">
                </td>
                <td>
                    <select id="unit_${rowCount}" name="details[${rowCount}][unit]" class="form-control unit-dropdown">
                        @foreach ($itemUnits as $unit)
                            <option value="{{$unit->unit}}">{{$unit->unit_name}}</option>
                        @endforeach
                    </select>
                    <input type="hidden" id="conversion_value_${rowCount}" name = "details[${rowCount}][conversion_value]" />
                </td>
                <td>
                    <input type="text" name="details[${rowCount}][price]" oninput="formatNumber(this)" class="form-control price-input text-end" id="price_${rowCount}" value="0" required placeholder="Price">
                </td>
                <td>
                    <input type="text" name="details[${rowCount}][disc_percent]" oninput="formatNumber(this)" id="disc_percent_${rowCount}" class="form-control text-end" value="0" required placeholder="% Discount">
                </td>
                <td>
                    <input type="text" name="details[${rowCount}][disc_nominal]" oninput="formatNumber(this)" id="disc_nominal_${rowCount}" class="form-control text-end" value="0" required placeholder="Discount">
                </td>
                <td>
                    <input type="text" name="details[${rowCount}][nominal]" oninput="formatNumber(this)" readonly id="nominal_${rowCount}" class="form-control text-end nominal" value="0" required placeholder="Discount">
                </td>
                <td>
                    <button type="button" class="btn btn-danger remove-row"><i class="material-icons-outlined remove-row">delete</i></button>
                </td>
            `;

            detailsTableBody.appendChild(newRow);
            setupItemSearch(rowCount);
            setupUnitChangeListener(rowCount);
            document.getElementById(`item_code_${rowCount}`).addEventListener('change', updatePrice);
            document.getElementById(`qty_${currentRow}`).addEventListener('input', function() {
                updateNominalValue(currentRow); // Call the function when the event occurs
            });

            document.getElementById(`price_${currentRow}`).addEventListener('input', function() {
                updateNominalValue(currentRow); // Call the function when the event occurs
            });
            document.getElementById(`disc_percent_${currentRow}`).addEventListener('input', function() {
                updateNominalValue(currentRow); // Call the function when the event occurs
            });
            document.getElementById(`disc_nominal_${currentRow}`).addEventListener('input', function() {
                updateNominalValue(currentRow); // Call the function when the event occurs
            });
            calculateTotals();
            addInputListeners();
            rowCount++; // Increment row count for the next row
        }

        // Function to update price based on item and unit selections


        // Add event listener for adding a new row
        document.getElementById('add-row').addEventListener('click', addNewRow);

        // Event delegation for row removal
        document.querySelector('#cash-out-details-table').addEventListener('click', function (e) {
            if (e.target && e.target.classList.contains('remove-row')) {
                e.target.closest('tr').remove();
                rowCount--; // Decrement row count
            }
        });

        // Initialize the first row
    });

    $(document).ready(function (x) {
        x = {
            headers: {
                "X-CSRF-TOKEN": "{{csrf_token()}}"
            }
        }
        $.ajaxSetup(x)
    });

    {{--$("#bank-cash-out-form").on("submit",function(e) {
        let formData = new FormData(this);
        let aa = true;
        if($("#checkHPP").val() == 1 ||$("#checkHPP").val() == "1"){
            aa = false;
        }
        if(aa){
            e.preventDefault();
            $.ajax({
                url: "{{ route('hpp') }}",
                type: "POST",
                data: formData,
                success: function (rs) {
                    if(rs.length > 0){
                        let itName = "";
                        rs.forEach((a) => itName = itName.concat("<li>",a.item_name,"</li>"));
                        itName = "<ul>"+itName+"</ul>";
                        Swal.fire({
                            title: 'Tidak bisa disimpan!',
                            html: "Item berikut harga penjualan dibawah HPP<br/>"+itName,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }else{
                        $("#checkHPP").val(1);
                        $("#bank-cash-out-form").submit();
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    //let data = JSON.parse(xhr.responseText);
                },
                cache: false,
                contentType: false,
                processData: false,
            });
        }
    });--}}
</script>
@endsection

@endsection
