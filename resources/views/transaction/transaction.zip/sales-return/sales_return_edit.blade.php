@extends('layouts.master')

@section('title', __('Sales Return'))

@section('css')
    <style>
        .dropdown-menu {
            position: absolute;
            z-index: 1000;
            background-color: white;
            border: 1px solid #ccc;
            width: 100%;
            max-height: 200px;
            overflow-y: auto;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }

        .item-list li {
            padding: 8px;
            cursor: pointer;
        }

        .item-list li:hover,
        .item-list li.highlight {
            background-color: #007bff;
            color: white;
        }

        .alert {
            display: none;
            margin-top: 5px;
            padding: 15px;
            border-radius: 5px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .fade {
            opacity: 0;
            transition: opacity 0.5s ease;
        }

        .fade.show {
            opacity: 1;
        }

        .card {
            margin-bottom: 1rem;
            padding: 15px;
        }

        .form-group label {
            margin-bottom: 0.5rem;
        }

        .qtyw {
            min-width: 150px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            margin-bottom: 0.5rem;
        }

        .content {
            padding-top: 20px;
            padding-left: 10px;
            padding-right: 10px;
            max-width: 100%;
            width: calc(100% - 240px);
            margin-left: 240px;
        }

        .submit-btn {
            margin-top: 20px;
        }



        @media (max-width: 768px) {
            .content {
                padding-left: 10px;
                padding-right: 10px;
                padding-top: 10px;
                width: 100%;
                margin-left: 0;
            }
        }

        .info-button {
            background-color: #ccc;
            color: #555;
            border: none;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            cursor: pointer;
            line-height: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        /* Mini modal styling */
        .mini-modal {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            color: #333;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            max-width: 230px; /* Set max width */
            word-wrap: break-word; /* Ensure word wrapping */
            white-space: normal; /* Allow text to wrap */
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
        }

    </style>
@endsection

@section('content')
    <x-page-title title="Transaction" pagetitle="{{__('Sales Return')}}" />
    <hr>
    <div class="container content">
        <h2>{{__('Sales Return')}} Edit</h2>
        <form id="print-form" target="_BLANK" action="{{ route('transaction.sales_return.print', $salesReturn->id) }}" method="GET"
            style="display:inline;">
            <button type="submit" class="mb-3 btn btn-dark" @if(!in_array('print', $privileges)) disabled @endif>
                Print SR</button>
        </form>
        <form id="po-form" action="{{ route('transaction.sales_return.update', $salesReturn->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="card mb-3">
                <div class="card-header">{{__('Sales Return')}} {{__('Information')}}</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            {{-- <div class="form-group">
                                <label for="search">{{__('Search Customer')}}</label>
                                <input type="text" id="search" class="form-control"
                                    placeholder="Search by Customer Code, Name, or Address">
                                <div id="search-results" class="list-group"
                                    style="display:none; position:relative; z-index:1000; width:100%;"></div>
                            </div> --}}
                            <div class="form-group">
                                <label for="customer_code">{{__('Customer Code')}}</label>
                                <input type="text" name="customer_code" id="customer_code" class="form-control" readonly value="{{ $salesReturn->customer_code }}">
                            </div>
                            <div class="form-group">
                                <label for="customer_name">{{__('Customer Name')}}</label>
                                <input type="text" name="customer_name" id="customer_name" class="form-control" readonly value="{{ $salesReturn->customers->customer_name }}">
                            </div>
                            <div class="form-group">
                                <label for="address">{{__('Address')}}</label>
                                <input type="text" name="address" id="address" class="form-control" readonly value="{{ $salesReturn->customers->address }}">
                            </div>

                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="department_code">{{__('Sales Invoice Number')}}</label>
                                <input type="text" name="sales_invoice_number" id="sales_invoice_number" class="form-control" readonly value="{{ $salesReturn->sales_invoice_number }}" readonly>
                            </div>
                            <div class="form-group">
                                {{-- <label for="department_code">Department</label> --}}
                                <input type="hidden" name="department_code" id="department_code" class="form-control" readonly value="{{ $salesReturn->department_code }}" required>
                            </div>
                            <div class="form-group">
                                <label for="notes">{{__('Notes')}}</label>
                                <textarea name="notes" class="form-control" value="" rows="4">{{ $salesReturn->notes }}</textarea>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="document_date">{{__('Document Date')}}</label>
                                <input type="date" id="document_date" name="document_date" class="form-control date-picker" required
                                    value="{{ $salesReturn->document_date }}" readonly>
                            </div>
{{--
                            <label for="exampleInputEmail1" class="form-label">Include</label>
                            <div class="form-group">
                                <input type="radio" name="include" value="yes" id="include_yes" {{ old('include') === 'yes' ? 'checked' : '' }} required>
                                <label for="include_yes">Yes</label><br>

                                <input type="radio" name="include" value="no" id="include_no" {{ old('include') === 'no' ? 'checked' : '' }}>
                                <label for="include_no">No</label><br>
                            </div> --}}

                            <div class="form-group">
                                <label for="tax">{{__('Tax')}}</label>
                                <div class="input-group mb-2">
                                    <input type="text" class="form-control" value="PPN / VAT" readonly>
                                    <select hidden class="form-select" id="tax" name="tax">
                                        @foreach ($taxs as $tax)
                                            <option value="{{ $salesReturn->tax_code }}" {{ old('tax', $salesReturn->tax) === $tax->tax_code ? 'selected' : '' }}>
                                                {{ $tax->tax_name . ' (' . $tax->tax_code . ')' }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <input type="hidden" name="company_code" value="{{ $salesReturn->company_code }}"
                                class="form-control" readonly>
                        </div>
                    </div>
                </div>
            </div>



            <div class="card mb-3">
                <div class="card-header">{{__('Sales Return')}} Details</div>
                <div class="card-body">
                    <h5 class="text-end">Total sebelum pajak: <span id="total-value">0</span></h5>
                    <div style="overflow-x: auto;">
                    <table class="table" id="pr-details-table">
                        <thead>
                            <td style="min-width: 430px">{{__('Item')}}</td>
                            <td style="min-width: 150px">Unit</td>
                            <td style="min-width: 150px">Qty</td>
                            <td style="min-width: 200px">{{__('Price')}}</td>
                            <td style="min-width: 200px">{{__('Discount')}} <button type="button" class="info-button" id="infoBtn">?</button></td>
                            <td style="min-width: 230px">Nominal</td>
                            <td>Action</td>
                        </thead>
                        <tbody id="parentTbody">
                            @foreach ($salesReturn->details as $index => $detail)
                                <tr>
                                    <td>
                                        <input type="hidden" name="details[{{ $index }}][item_id]" class="form-control" value="{{ $detail->item_id }}" readonly />
                                        <input type="text" name="details[{{ $index }}][item_name]" class="form-control" value="{{ $detail->items->item_name }}" readonly />
                                    </td>
                                    <td>
                                        <input type="hidden" name="details[{{ $index }}][unit]" class="form-control" value="{{ $detail->unit }}" readonly />
                                        <input type="text" name="details[{{ $index }}][unit_name]" class="form-control" value="{{ $detail->units->unit_name }}" readonly />
                                    </td>
                                    <td>
                                        <input type="number" id="qty_{{$index}}" name="details[{{ $index }}][qty]" class="form-control" value="{{ $detail->qty }}" min="1" max="{{ $purchsaeInvoiceDetails->where('item_id', $detail->item_id)->where('unit', $detail->unit)->sum('qty_left') + $detail->qty }}"/>
                                        <input type="hidden" name="details[{{ $index }}][disc_percent]" step="1" class="form-control" value="{{ $detail->disc_percent }}"  />
                                        <input type="hidden" name="details[{{ $index }}][disc_header]" step="1" class="form-control" value="{{ $detail->disc_header }}"  />
                                        <input type="hidden" name="details[{{ $index }}][disc_nominal]" step="1000" class="form-control" value="{{ $detail->disc_nominal }}"  />
                                    </td>
                                    <td>
                                        <input type="text" id="price_{{$index}}" name="details[{{ $index }}][price]" class="form-control text-end" value="{{ number_format($detail->price,0,'.',',') }}" readonly />
                                    </td>
                                    <td>
                                        <input type="text" id="disc_total_{{$index}}" class="form-control text-end" value="{{ number_format((($detail->disc_nominal)+($detail->disc_percent*$detail->price*$detail->qty)+$detail->disc_header),0,'.',',') }}" readonly />
                                    </td>
                                    <td>
                                        <input type="text" id="nominal_{{$index}}" class="form-control text-end nominal" value="{{ number_format(($detail->price*$detail->qty)-(($detail->disc_nominal)+($detail->disc_percent*$detail->price*$detail->qty)+$detail->disc_header),0,'.',',') }}" readonly />
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-danger deleteRow"><i class="material-icons-outlined remove-row">remove</i></button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    </div>
                    {{-- <button type="button" class="btn btn-secondary mt-3" id="addRow">Add Row</button> --}}
                </div>
            </div>

            <button type="submit" class="mb-3 btn btn-primary" @if(!in_array('update', $privileges)) disabled @endif>Update {{__('Sales Return')}}</button>
        </form>
        <form id="delete-form" action="{{ route('transaction.sales_return.destroy', $salesReturn->id) }}" method="POST" style="display:inline;" >
            @csrf
            @method('POST')
            <button type="button" class="btn btn-sm btn-danger mb-3" onclick="confirmDelete(event,'{{ $salesReturn->id }}')"
                @if(!in_array('delete', $privileges)) disabled @endif
            ><i class="material-icons-outlined">delete</i></button>
        </form>
        <div class="mini-modal" id="miniModal">
            The discount is accumulated from all discounts in invoices per Item.
        </div>
    </div>






    @if (session('success'))
        <script>
            Swal.fire({
                title: 'Success!',
                text: "{{ session('success') }}",
                icon: 'success',
                confirmButtonText: 'OK'
            });
        </script>
    @endif

    @if (session('error'))
        <script>
            Swal.fire({
                title: 'Error!',
                text: "{{ session('error') }}",
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>
    @endif
@endsection



@section('scripts')
<script>
    function confirmDelete(event, id) {
        event.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: 'Do you want to delete this sales return?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            confirmButtonColor: '#0c6efd',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form').submit();
            }
        });
    }

    const infoBtn = document.getElementById("infoBtn");
        const miniModal = document.getElementById("miniModal");

        // Toggle modal visibility
        infoBtn.addEventListener("click", function(event) {
            miniModal.style.display = miniModal.style.display === "block" ? "none" : "block";

            // Position the modal near the button
            miniModal.style.left = `${event.pageX + 10}px`;
            miniModal.style.top = `${event.pageY + 10}px`;
        });

        // Hide modal when clicking outside
        document.addEventListener("click", function(event) {
            if (event.target !== infoBtn && event.target !== miniModal) {
                miniModal.style.display = "none";
            }
        });
    let prDetails = @json($salesReturn->details);
    let piDetails = @json($purchsaeInvoiceDetails);
    let rowCount = prDetails.length;

    for (let i = 0; i < rowCount; i++) {
        document.getElementById(`qty_${i}`).addEventListener('input', function() {
            updateNominalValue(i); // Call the function when the event occurs
        });

    }

    function getAvailableItems() {
        let usedItems = prDetails.map(detail => {
            return {
                item_id: detail.item_id,
                unit: detail.unit
            };
        });

        return piDetails.filter(item => {
            return !usedItems.some(usedItem =>
                usedItem.item_id === item.item_id && usedItem.unit === item.unit
            );
        });
    }

    function updateNominalValue(row) {
        const qty = parseFloat(document.getElementById(`qty_${row}`).value) || 0;
        const price = document.getElementById(`price_${row}`).value.replace(/,/g, '') || 0;
        const disc_nominal_header = 0;
        const disc_total = document.getElementById(`disc_total_${row}`).value.replace(/,/g, '') || 0;;
        // const disc_percent = parseFloat(document.getElementById(`disc_percent_${row}`).value.replace(/,/g, '')) || 0;
        // const disc_nominal = parseFloat(document.getElementById(`disc_nominal_${row}`).value.replace(/,/g, '')) || 0;

        const nominalInput = document.getElementById(`nominal_${row}`);
        const nominalValue = ((qty * price)-(disc_total))+"";

        let formattedValue = nominalValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

        nominalInput.value = formattedValue; // Update nominal value
        calculateTotals();
    }


function calculateTotals() {
        let total = 0;
        const disc_nominal = 0;
        document.querySelectorAll('.nominal').forEach(function (input) {

            input.value = input.value.replace(/,/g, ''); // Remove any thousand separators
            if(input.id=='disc_nominal'){
                total -= parseFloat(input.value) || 0;
            }else{
                total += parseFloat(input.value) || 0;
            }
            const cursorPosition = input.selectionStart;
            let value = input.value.replace(/,/g, '');
            // Format the number with thousand separators
            let formattedValue = value.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

            // Set the new value
            input.value = formattedValue;

            // Adjust the cursor position
            const newCursorPosition = formattedValue.length - (value.length - cursorPosition);
            input.setSelectionRange(newCursorPosition, newCursorPosition);
        });
        let strTotal = (total)+"";
        let value2 = strTotal.replace(/,/g, '');
            // Format the number with thousand separators
        let formattedValue2 = value2.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        document.getElementById('total-value').innerText = formattedValue2;

        return { total }; // Return totals for validation
    }
    calculateTotals();
    function addInputListeners() {
        document.querySelectorAll('.nominal').forEach(function (input) {
            input.addEventListener('change', function () {

                calculateTotals(); // Calculate totals when any input changes
            });
        });
    }
    addInputListeners();

    function addNewRow(item) {
    let newRow = `
        <tr>
            <td>
                <input type="hidden" name="details[${rowCount}][item_id]" class="form-control" value="${item.item_id}" readonly />
                <input type="text" name="details[${rowCount}][item_name]" class="form-control" value="${item.items.item_name}" readonly />
            </td>
            <td>
                <input type="hidden" name="details[${rowCount}][unit]" class="form-control" value="${item.unit}" readonly />
                <input type="text" name="details[${rowCount}][unit_name]" class="form-control" value="${item.units.unit_name}" readonly />
            </td>
            <td>
                <input type="number" name="details[${rowCount}][qty]" class="form-control" value="${item.qty_left}" min="1" max="${item.qty_left}"/>
                <input type="hidden" name="details[${rowCount}][disc_percent]" step="1" class="form-control" value="${item.disc_percent}"  />
                <input type="hidden" name="details[${rowCount}][disc_header]" step="1" class="form-control" value="${item.disc_header}"  />
                <input type="hidden" name="details[${rowCount}][disc_nominal]" step="1000" class="form-control" value="${item.disc_nominal}"  />
            </td>
            <td>
                <input type="number" name="details[${rowCount}][price]" class="form-control" value="${item.price}" readonly />
            </td>
            <td>
                <input type="text" name="details[${rowCount}][notes]" class="form-control" value="" />
            </td>
            <td>
                <button type="button" class="btn btn-danger deleteRow"><i class="material-icons-outlined remove-row">remove</i></button>
            </td>
        </tr>
        `;
        $('#parentTbody').append(newRow);
    }

    $('#addRow').click(function() {
        let availableItems = getAvailableItems();
        if (availableItems.length === 0) {
            alert("No available items to add.");
            return;
        }
        let itemSelect = '<select id="itemSelect" class="form-control">';
        availableItems.forEach(item => {
            console.log(item);

            itemSelect += `<option value='${JSON.stringify(item)}'>${item.items.item_name} (${item.units.unit_name})</option>`;
        });
        itemSelect += '</select>';

        // Show a prompt to select an item
        Swal.fire({
            title: 'Select an Item',
            html: itemSelect,
            showCancelButton: true,
            confirmButtonText: 'Add',
            preConfirm: () => {
                const selectedItem = JSON.parse(document.getElementById('itemSelect').value);
                addNewRow(selectedItem);
            }
        });


        rowCount++;
    });


    $('#pr-details-table').on('click', '.remove-row', function() {
        $(this).closest('tr').remove();
    });



    </script>
@endsection
