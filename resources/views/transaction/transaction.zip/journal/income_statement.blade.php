@extends('layouts.master')

@section('title', 'Income Statement Information')

@section('css')
    <style>
        .btn-square {
            width: 100px;
        }
        .table th, .table td {
            text-align: left;
            vertical-align: middle;
            padding: 12px;
        }
        .table thead {
            background-color: #f2f2f2;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }
        .table td, .table th {
            word-wrap: break-word;
            overflow: hidden;
            max-width: 150px;
        }
        .table td {
            padding: 10px;
            border-top: 1px solid #ddd;
            border-bottom: 1px solid #ddd;
        }
        .table th {
            background-color: #f8f8f8;
            font-weight: bold;
            border-bottom: 2px solid #ddd;
        }
        .table td, .table th {
            border-left: none;
            border-right: none;
        }
        #incomeStatementTable_wrapper {
            margin-top: 20px;
        }
        .account-type-header {
            font-weight: bold;
            font-size: 16px;
        }
        .account-sub-type {
            padding-left: 30px; /* Indentation for subtypes */
            font-weight: bold;
        }
        .account-name {
            padding-left: 50px; /* Further indentation for account names */
        }
        .account-number {
            text-align: right; /* Align account number to the right */
        }
        .total-row {
            font-weight: bold;
            background-color: #f2f2f2;
        }
    </style>
@endsection

@section('content')
    <x-page-title title="Income Statement" pagetitle="Income Statement {{__('Information')}}" />
    <hr>

    <div class="card">
        <div class="card-body">
            <h6 class="mb-4 text-uppercase">Income Statement {{__('Information')}}</h6>

            <!-- Date Filters -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <label for="date_from">Date From:</label>
                    <div class="input-group">
                        <input type="date" id="date_from" class="form-control date-picker filter-date me-0">
                        <button type="button" class="btn btn-danger clear-date" data-target="#date_from">
                            <i class="material-icons-outlined">close</i>
                        </button>
                    </div>
                </div>

                <div class="col-md-3">
                    <label for="date_to">Date To:</label>
                    <div class="input-group">
                        <input type="date" id="date_to" class="form-control date-picker filter-date me-0">
                        <button type="button" class="btn btn-danger clear-date" data-target="#date_to">
                            <i class="material-icons-outlined">close</i>
                        </button>
                    </div>
                </div>

                <div class="col-md-2 pt-4">
                    <button type="button" class="btn btn-primary" id="btn-search">Search</button>
                </div>
            </div>

            <!-- Print Button -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <button type="button" class="btn btn-secondary btn-square" id="btn-print">Print</button>
                </div>
            </div>

            <!-- Data Table -->
            <div class="table-responsive">
                <table id="incomeStatementTable" class="table table-hover mt-3">
                    <thead>
                        <tr>
                            <th>Account</th>
                            <th>Account Code</th>
                            <th>Balance</th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                        <!-- Data will be inserted here dynamically -->
                    </tbody>
                </table>
            </div>
            <p class="text-center mt-4" id="noDataMessage">Please select a date range and click "Search" to view the income statement data.</p>
        </div>
    </div>
@endsection

@section('scripts')
<script src="{{ URL::asset('build/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('build/plugins/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
<script>
    $(document).ready(function() {
        // Initialize DataTable
        const table = $('#incomeStatementTable').DataTable({
            paging: true,
            searching: true,
            ordering: true,
            info: true,
            autoWidth: false,
            responsive: true,
        });

        // Initially hide table and show message
        $('#noDataMessage').show();
        $('#incomeStatementTable').parent().hide(); // Hide table initially

        // Function to clear the date input fields
        function clearDateInput(inputId) {
            $(inputId).val(''); // Reset the value of the input field
        }

        // Handle the date "delete" button clicks
        $('.clear-date').on('click', function() {
            var target = $(this).data('target');
            clearDateInput(target);
        });

        // When search button is clicked
        $('#btn-search').on('click', function() {
            let dateFrom = $('#date_from').val();
            let dateTo = $('#date_to').val();

            if (!dateFrom || !dateTo) {
                alert('Please select both Date From and Date To.');
                return;
            }

            // Fetch the data using AJAX based on selected date range
            $.ajax({
                url: '{{ route("transaction.journal.fetchIncomeStatement") }}',
                type: 'GET',
                data: { date_from: dateFrom, date_to: dateTo },
                beforeSend: function() {
                    $('#table-body').empty(); // Clear existing rows
                    $('#noDataMessage').hide(); // Hide no data message
                    $('#incomeStatementTable').parent().show(); // Show table when data is being loaded
                },
                success: function(response) {
                    console.log("Response Data:", response.data); // Log the full response data
                    let grandTotal = 0;

                    if (response.data && Object.keys(response.data).length > 0) {
                        // Loop through account types (top-level category)
                        $.each(response.data, function(accountType, accountSubTypes) {
                            let typeTotal = 0; // Initialize total for the current account type

                            // Add Account Type row
                            $('#table-body').append(`
                                <tr class="account-type-header">
                                    <td><strong>${accountType}</strong></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            `);

                            // Loop through account subtypes (second-level category)
                            $.each(accountSubTypes, function(subType, accounts) {
                                // Add Account Sub Type row
                                $('#table-body').append(`
                                    <tr class="account-sub-type">
                                        <td>${subType}</td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                `);

                                // Loop through accounts under each sub type (third-level)
                                $.each(accounts, function(i, account) {
                                    // Add Account Name, Account Number, and Balance row
                                    $('#table-body').append(`
                                        <tr class="account-name">
                                            <td>${account.account_name}</td>
                                            <td class="account-number">${account.account_number || 'N/A'}</td> <!-- Align account number to the right -->
                                            <td>${account.balance}</td>
                                        </tr>
                                    `);

                                    // Add to the account type total and the grand total
                                    typeTotal += parseFloat(account.balance) || 0;
                                    grandTotal += parseFloat(account.balance) || 0;
                                });
                            });

                            // Add total for current account type
                            $('#table-body').append(`
                                <tr class="total-row">
                                    <td><strong>Total for ${accountType}</strong></td>
                                    <td></td>
                                    <td><strong>${typeTotal.toFixed(2)}</strong></td>
                                </tr>
                            `);
                        });

                        // Add the grand total
                        $('#table-body').append(`
                            <tr class="total-row">
                                <td><strong>Grand Total</strong></td>
                                <td></td>
                                <td><strong>${grandTotal.toFixed(2)}</strong></td>
                            </tr>
                        `);

                        $('#noDataMessage').hide(); // Hide "No Data" message when data is available
                    } else {
                        $('#noDataMessage').show(); // Show "No Data" message if no data
                    }
                },
                error: function(error) {
                    console.error("Error:", error); // Log any errors
                    alert('An error occurred. Please try again.');
                }
            });
        });

        // Handle the print button click, routing to "income_statement_print" with dates as query parameters
        $('#btn-print').on('click', function() {
            let dateFrom = $('#date_from').val();
            let dateTo = $('#date_to').val();

            if (!dateFrom || !dateTo) {
                alert('Please select both Date From and Date To before printing.');
                return;
            }

            // Redirect to the income statement print route with date parameters
            window.location.href = '{{ route("transaction.journal.income_statement.print") }}?date_from=' + dateFrom + '&date_to=' + dateTo;
        });
    });
</script>
@endsection
