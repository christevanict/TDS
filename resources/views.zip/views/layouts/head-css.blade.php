<!--plugins-->
<link href="{{ URL::asset('build/plugins/perfect-scrollbar/css/perfect-scrollbar.css') }}" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="{{ URL::asset('build/plugins/metismenu/metisMenu.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ URL::asset('build/plugins/metismenu/mm-vertical.css') }}"> 
  <link rel="stylesheet" type="text/css" href="{{ URL::asset('build/plugins/simplebar/css/simplebar.css') }}">
  <!--bootstrap css-->
  <link href="{{ URL::asset('build/css/bootstrap.min.css') }}" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Material+Icons+Outlined" rel="stylesheet">
  <!--main css-->
  <link href="{{ URL::asset('build/css/bootstrap-extended.css') }}" rel="stylesheet">
  <link href="{{ URL::asset('build/sass/main.css') }}" rel="stylesheet">
  <link href="{{ URL::asset('build/sass/dark-theme.css') }}" rel="stylesheet">
  <link href="{{ URL::asset('build/sass/semi-dark.css') }}" rel="stylesheet">
  <link href="{{ URL::asset('build/sass/bordered-theme.css') }}" rel="stylesheet">
  <link href="{{ URL::asset('build/sass/responsive.css') }}" rel="stylesheet">
  