<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--favicon-->
<link rel="icon" href="{{ URL::asset('build/images/favicon-32x32.png') }}" type="image/png">
<title><?= ($title) ? $title : '' ?> | CI & Bootstrap 5 Admin Dashboard Template</title>
