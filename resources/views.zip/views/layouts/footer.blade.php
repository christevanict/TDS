<!--start footer-->
<footer class="page-footer">
    <p class="mb-0">Copyright © <script>document.write(new Date().getFullYear())</script> . All right reserved.</p>
  </footer>
  