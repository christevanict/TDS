@extends('layouts.master')

@section('title', 'Journal Information')

@section('css')
<style>
    .clickable-row {
        cursor: pointer;
    }

    .clickable-row:hover, .clickable-row:focus {
        background-color: #f1f1f1;
    }

    .btn-insert {
        margin-bottom: 20px;
    }

    .btn-print, .btn-edit {
        margin-right: 10px; /* Add space between buttons */
    }
</style>
@endsection

@section('content')
<x-page-title title="Journal" pagetitle="Receivable Report" />
<hr>

<div class="card">
    <div class="card-body">

        <div class="table-responsive ">
            <h1>Receivable Aging Report</h1>
            <p>Date: {{ $today->format('d-M-Y') }}</p>
            {{-- <p>Total Outstanding: ${{ number_format($totalOutstanding, 2) }}</p> --}}
            <div class="row mb-3 ">
                <div class="">
                        <a href="{{route('transaction.journal.ReceivableAgingPdf')}}" target="_blank">

                            <button type="submit" class="btn btn-secondary btn-square print-button" id="btn-print">View Detail</button>
                        </a>
                </div>
            </div>
            <table id="example" class="table table-hover table-bordered mt-3" style="width:100%">
                <thead>
                    <tr>
                        <th>Invoice Number</th>
                        <th>Invoice Date</th>
                        <th>Total Amount Due</th>
                        <th>Not Yet Due (0 Day)</th>
                        <th>1-30 Days</th>
                        <th>31-60 Days</th>
                        <th>61-90 Days</th>
                        <th>Over 90 Days</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($agingReport as $customerName => $report)
                        <tr>
                            <td>{{ $customerName }}</td>
                            <td></td>
                            <td>{{ number_format($report['total_amount_due']) }}</td>
                            <td>{{ number_format($report['aging']['0'], 2) }}</td>
                            <td>{{ number_format($report['aging']['1-30']) }}</td>
                            <td>{{ number_format($report['aging']['31-60']) }}</td>
                            <td>{{ number_format($report['aging']['61-90']) }}</td>
                            <td>{{ number_format($report['aging']['over_90']) }}</td>
                        </tr>
                        @foreach($report['debts'] as $debt)
                            @php
                                // Use the 'umur' property set in the controller to determine the aging group
                                $agingGroup = '';
                                if ($debt->umur == 0) {
                                    $agingGroup = '0';
                                } elseif ($debt->umur > 0 && $debt->umur <= 30) {
                                    $agingGroup = '1-30';
                                } elseif ($debt->umur > 30 && $debt->umur <= 60) {
                                    $agingGroup = '31-60';
                                } elseif ($debt->umur > 60 && $debt->umur <= 90) {
                                    $agingGroup = '61-90';
                                } else {
                                    $agingGroup = 'over_90';
                                }
                            @endphp
                            <tr>
                                <td>{{ $debt->document_number }}</td>
                                <td>{{ $debt->document_date }}</td>
                                <td>{{ number_format($debt->debt_balance, 2) }}</td>
                                <td>
                                    @if($agingGroup == '0')
                                        {{ number_format($debt->debt_balance) }}
                                    @else
                                        0
                                    @endif
                                </td>
                                <td>
                                    @if($agingGroup == '1-30')
                                        {{ number_format($debt->debt_balance) }}
                                    @else
                                        0
                                    @endif
                                </td>
                                <td>
                                    @if($agingGroup == '31-60')
                                        {{ number_format($debt->debt_balance) }}
                                    @else
                                        0
                                    @endif
                                </td>
                                <td>
                                    @if($agingGroup == '61-90')
                                        {{ number_format($debt->debt_balance) }}
                                    @else
                                        0
                                    @endif
                                </td>
                                <td>
                                    @if($agingGroup == 'over_90')
                                        {{ number_format($debt->debt_balance) }}
                                    @else
                                        0
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@if (session('success'))
<script>
    Swal.fire({
        title: 'Success!',
        text: "{{ session('success') }}",
        icon: 'success',
        confirmButtonText: 'OK'
    });
</script>
@endif

@if (session('error'))
<script>
    Swal.fire({
        title: 'Error!',
        text: "{{ session('error') }}",
        icon: 'error',
        confirmButtonText: 'OK'
    });
</script>
@endif

@endsection

@section('scripts')
<script src="{{ URL::asset('build/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('build/plugins/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
<script>
    $(document).ready(function() {

    } );
</script>
@endsection
