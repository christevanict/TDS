@extends('layouts.master')

@section('title', 'Journal Information')

@section('css')
<style>
    .clickable-row {
        cursor: pointer;
    }

    .clickable-row:hover, .clickable-row:focus {
        background-color: #f1f1f1;
    }

    .btn-insert {
        margin-bottom: 20px;
    }

    .btn-print, .btn-edit {
        margin-right: 10px; /* Add space between buttons */
    }
</style>
@endsection

@section('content')
<x-page-title title="Journal" pagetitle="Payable Report" />
<hr>

<div class="card">
    <div class="card-body">
        <h6 class="mb-2 text-uppercase">Payable Report</h6>
        <div class="row mb-3 ">
            <div class="">
                    <a href="{{route('transaction.journal.payableReport.pdf')}}" target="_blank">

                        <button type="submit" class="btn btn-secondary btn-square print-button" id="btn-print">View Detail</button>
                    </a>
            </div>
        </div>
        <div class="table-responsive ">
            <table id="example" class="table table-hover table-bordered mt-3" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>{{__('Supplier')}}</th>
                        <th>{{__('Purchase Invoice Number')}}</th>
                        <th>{{__('Purchase Invoice Date')}}</th>
                        <th>{{__('Due Date')}}</th>
                        <th>Total Hutang</th>
                        <th>Total Terbayar</th>
                        <th>Sisa Hutang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                        @foreach ($suppliers as $supplier)
                            @foreach ($supplier->debts as $debt)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>{{ $supplier->supplier_name }}</td>
                                    <td>{{ $debt->document_number }}</td>
                                    <td>{{ \Carbon\Carbon::parse($debt->document_date)->format('d M Y') }}</td>
                                    <td>{{ \Carbon\Carbon::parse($debt->due_date)->format('d M Y') }}</td>
                                    <td class="text-end">{{ number_format($debt->total_debt,2) }}</td>
                                    <td class="text-end">{{ number_format($debt->{'Amount Paid'},2) }}</td>
                                    <td class="text-end">{{ number_format($debt->debt_balance,2) }}</td>
                                </tr>
                            @endforeach
                        @endforeach
                </tbody>
                <tfoot>

                </tfoot>
            </table>
        </div>
    </div>
</div>

@if (session('success'))
<script>
    Swal.fire({
        title: 'Success!',
        text: "{{ session('success') }}",
        icon: 'success',
        confirmButtonText: 'OK'
    });
</script>
@endif

@if (session('error'))
<script>
    Swal.fire({
        title: 'Error!',
        text: "{{ session('error') }}",
        icon: 'error',
        confirmButtonText: 'OK'
    });
</script>
@endif

@endsection

@section('scripts')
<script src="{{ URL::asset('build/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('build/plugins/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
<script>

</script>
@endsection
