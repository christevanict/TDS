@extends('layouts.master')

@section('title', 'Trial Balance Information')

@section('css')
    <style>
        /* Your existing styles */
        .btn-square {
            width: 100px; /* Adjust as needed for desired square size */
        }
    </style>
@endsection

@section('content')
    <x-page-title title="Trial Balance" pagetitle="Trial Balance {{__('Information')}}" />
    <hr>

    <div class="card">
        <div class="card-body">
            <h6 class="mb-2 text-uppercase">Trial Balance {{__('Information')}}</h6>
            <div class="row mb-3">
                <!-- Date From Filter -->
                <div class="col-md-3">
                    <label for="date_from">Date From:</label>
                    <div class="input-group">
                        <input type="date" id="date_from" class="form-control date-picker filter-date me-0">
                        <button type="button" class="btn btn-danger clear-date" data-target="#date_from">
                            <i class="material-icons-outlined">close</i>
                        </button>
                    </div>
                </div>

                <!-- Date To Filter -->
                <div class="col-md-3">
                    <label for="date_to">Date To:</label>
                    <div class="input-group">
                        <input type="date" id="date_to" class="form-control date-picker filter-date me-0">
                        <button type="button" class="btn btn-danger clear-date" data-target="#date_to">
                            <i class="material-icons-outlined">close</i>
                        </button>
                    </div>
                </div>

                <!-- Search Button -->
                <div class="col-md-2 pt-4">
                    <button type="button" class="btn btn-primary" id="btn-search">Search</button>
                </div>
            </div>

            <div class="row mb-3">
                <!-- Print Button -->
                <div class="col-md-3">
                    <button type="button" class="btn btn-secondary btn-square print-button" id="btn-print">Print</button>
                </div>
            </div>

            <!-- DataTable -->
            <div class="table-responsive">
                <table id="trialBalanceTable" class="table table-hover mt-3" style="width:100%">
                    <thead>
                        <tr>
                            <th style="display: none">No</th>
                            <th>Account</th>
                            <th>Account Code</th>
                            <th>Debit</th>
                            <th>Credit</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{-- Data injected via AJAX --}}
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3" style="text-align:right">Total:</th>
                            <th id="totalDebit">0.00</th>
                            <th id="totalCredit">0.00</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="{{ URL::asset('build/plugins/datatable/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ URL::asset('build/plugins/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
    <script>
       $(document).ready(function() {
            var table = $('#trialBalanceTable').DataTable({
                lengthChange: false,
                columns: [
                    { data: 'number', visible: false },  // Hidden column for row number
                    { data: 'account' },
                    { data: 'account_code' },
                    { data: 'debit' },
                    { data: 'credit' },
                ],
                footerCallback: function(row, data, start, end, display) {
                    var api = this.api();
                    var totalDebit = 0;
                    var totalCredit = 0;

                    api.rows({ page: 'current' }).every(function() {
                        var row = this.data();
                        totalDebit += parseFloat(row.debit) || 0;
                        totalCredit += parseFloat(row.credit) || 0;
                    });

                    $(api.column(3).footer()).html(totalDebit.toFixed(2));
                    $(api.column(4).footer()).html(totalCredit.toFixed(2));
                }
            });

            $('#btn-search').on('click', function() {
                var dateFrom = $('#date_from').val();
                var dateTo = $('#date_to').val();
                var coaId = $('#coa_id').val();

                if (!dateFrom || !dateTo) {
                    alert('Please provide both Date From and Date To.');
                    return;
                }

                $.ajax({
                    url: '{{ route('transaction.journal.fetchTrialBalance') }}',
                    method: 'GET',
                    data: {
                        date_from: dateFrom,
                        date_to: dateTo,
                        coa_id: coaId
                    },
                    success: function(response) {
                        console.log(response);
                        let groupedData = groupByAccountType(response);
                        table.clear(); // Clear existing table data

                        groupedData.forEach(function(group, index) {
                            console.log(group);

                            // Add Account Type as a header row
                            table.row.add({
                                number: '', // Empty for account type row
                                account: `<div class="account-type-container"><strong class="account-type-header">${group.accountType}</strong></div>`,
                                account_code: '',
                                debit: '',
                                credit: ''
                            }).draw();

                            group.accounts.forEach(function(account) {
                                table.row.add({
                                    number: '', // Empty for account rows
                                    account: `<div class="account-item">${account.account}</div>`,
                                    account_code: account.account_code,
                                    debit: account.debit,
                                    credit: account.credit
                                }).draw();
                            });
                        });

                        table.draw(); // Redraw the table after adding all rows
                    },
                    error: function(xhr) {
                        console.error(xhr);
                        alert('An error occurred while fetching data.');
                    }
                });
            });

            function groupByAccountType(data) {
                var grouped = {};

                data.forEach(function(item) {
                    if (!grouped[item.account_sub_type]) {
                        grouped[item.account_sub_type] = [];
                    }
                    grouped[item.account_sub_type].push(item);
                });



                var accountTypes = Object.keys(grouped).sort();

                return accountTypes.map(function(accountType) {
                    return {
                        accountType: accountType,
                        accounts: grouped[accountType]
                    };
                });
            }

            $('#btn-print').on('click', function() {
                var dateFrom = $('#date_from').val();
                var dateTo = $('#date_to').val();
                var coaId = $('#coa_id').val();

                if (!dateFrom || !dateTo) {
                    alert('Please provide both Date From and Date To.');
                    return;
                }

                var url = `{{ route('transaction.journal.trial_balance.pdf') }}?date_from=${dateFrom}&date_to=${dateTo}&coa_id=${coaId}`;
                window.open(url, '_blank');
            });
        });
    </script>
@endsection
