<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1>This is a test email from Laravel!</h1>
</body>
</html>
